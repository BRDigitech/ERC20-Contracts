import chalk from "chalk";
// tslint:disable:no-var-requires
const chalkTable = require("chalk-table");

import { schedule } from "node-cron";
import { zrxWrapper } from "./zrx";
import { PAIRS } from "../constants";
import { Bid, Token } from "../types";
import { oneInchWrapper } from "./1inch";
import { tradingBotCall } from "./contract";
import { providers, utils } from "ethers";

import config from "./../../config";

class TradingBot {
  _orderBook: Map<string, string>;
  _provider: providers.JsonRpcProvider;

  constructor() {
    this._orderBook = new Map();

    this._provider = new providers.JsonRpcProvider(config.JSON_RPC);
  }

  /**
   * Entry Point
   */
  start = async () => {
    /// @dev Check markets every n seconds
    schedule(`*/${config.POLLING_INTERVAL} * * * * *`, () => {
      this._checkMarkets();
    });
  };

  private _checkMarkets = async () => {
    const markets = Object.values(PAIRS);
    for (let i = 0; i < markets.length; i++) {
      const quoteToken = markets[i].quote;
      const baseToken = markets[i].base;

      try {
        console.log(
          `Fetching market data for pair ${baseToken.symbol}-${
            quoteToken.symbol
          } @ ${new Date()} ...\n`
        );

        const bids = await zrxWrapper.getOrderBook(
          baseToken.address,
          quoteToken.address
        );

        console.info(
          `Found ${
            bids.length != 1
              ? bids.length + " bids orders"
              : bids.length + " bid order"
          }...\n---`
        );
        bids.forEach(
          async (bid, i) =>
            await this._checkArb({
              index: i + 1,
              bid,
              quoteToken,
              baseToken,
            })
        );
      } catch (error) {
        console.error(error);
      }
    }
  };
  /// @dev
  on_cooldown = false;
  private _checkArb = async (params: {
    bid: Bid;
    quoteToken: Token;
    baseToken: Token;
    index: number;
  }) => {
    const { bid, quoteToken, baseToken, index: i } = params;
    let zrxOrder = bid.order;
    if (!this.on_cooldown) {
      console.info(
        `${i}. Checking arbitrage for order ${zrxOrder.salt}...\n---`
      );
      const tracked = this._orderBook.get(zrxOrder.salt);

      /// Skip if order checked
      if (tracked) {
        console.info(`Skipping: order ${zrxOrder.salt} already checked.\n---`);
        return;
      }

      // Skip if Maker Fee
      // if (zrxOrder?.makerTokenFeeAmount !== "0") {
      //   console.info("Order has maker fee");
      //   return;
      // }

      // Skip if Taker Fee
      if (zrxOrder.takerTokenFeeAmount !== "0") {
        // Add to checked orders
        this._orderBook.set(zrxOrder.salt, zrxOrder.salt);
        console.info(`Skipping: order ${zrxOrder.salt} has taker fee.\n---`);
        return;
      }

      // // Fetch order status
      // const orderInfo: any = await zrxWrapper.fetchOrder(bid.metaData.orderHash);

      // Skip order if it's been partially filled
      if (bid.metaData?.remainingFillableTakerAmount !== zrxOrder.takerAmount) {
        console.log(
          `Skipping: order ${zrxOrder.salt} has partially been filled.`
        );
        console.log({
          takerAmount: zrxOrder.takerAmount,
          remainingFillableTakerAmount:
            bid.metaData.remainingFillableTakerAmount,
        });
        // Add to checked orders
        this._orderBook.set(zrxOrder.salt, zrxOrder.salt);

        return;
      }
      // Skip order if the base value(amount In) is WETH and the value is less than 0.001 WETH
      if (
        ["WETH", "DAI", "USDC"].includes(baseToken.symbol) &&
        parseFloat(
          utils.formatUnits(zrxOrder.makerAmount, baseToken.decimals)
        ) < 0.001
      ) {
        console.log(
          `Skipping: order ${baseToken.symbol}-${
            quoteToken.symbol
          },  ${utils.formatUnits(
            zrxOrder.makerAmount,
            baseToken.decimals
          )} less than 0.001 ${baseToken.symbol}.`
        );
        return;
      }

      // Fetch 1inch.exchange Data
      let oneInchExchangeData = null;
      // This becomes the outputAssetAmount
      let toTokenAmount = null;

      let zrxData = null;
      let fromTokenAmount = null;
      try {
        let { data, buyAmount } = await zrxWrapper.fetchQuote({
          sellToken: baseToken.symbol,
          buyToken: quoteToken.symbol,
          sellAmount: zrxOrder.makerAmount,
        });
        zrxData = data;

        // we sell 90% of the amount
        console.log({
          sellToken: baseToken.symbol,
          sellAmount: zrxOrder.makerAmount,
          buyAmount,
          buyToken: quoteToken.symbol,
        });

        fromTokenAmount = utils
          .parseUnits(buyAmount, 0)
          .mul(99)
          .div(100)
          .toString();
      } catch (error) {
        console.error(`Error:`, error);
        return;
      }
      try {
        let { oneInchExchangeData: data, toTokenAmount: toAmount } =
          await oneInchWrapper.buildTx({
            fromTokenAddress: quoteToken.address,
            toTokenAddress: baseToken.address,
            fromAddress: config.TRADING_BOT,
            destReceiver: config.TRADING_BOT,
            amount: fromTokenAmount, /// USDT  to WETH
          });
        toTokenAmount = toAmount;
        oneInchExchangeData = data;
      } catch (error) {
        // TODO uncomment to see 1inch errors
        // 1inch is reverting on amounts with big decimals (e.g. 0.0000001) WETH
        // console.error(`Error:`, error);
        return;
      }

      /// @dev TODO check the toTokenAmount and ensure that is  greater than 0.001
      if (
        parseFloat(utils.formatUnits(toTokenAmount, quoteToken.decimals)) <
        0.001
      ) {
        console.log(
          `Skipping: order ${baseToken.symbol}-${
            quoteToken.symbol
          },  ${utils.formatUnits(
            toTokenAmount,
            quoteToken.decimals
          )} less than 0.001 ${quoteToken.symbol}.`
        );
        return;
      }

      // Add to checked orders
      this._orderBook.set(zrxOrder.salt, zrxOrder.salt);
      if (oneInchExchangeData && zrxData) {
        // Calculate estimated gas cost
        let _gasPrice = await this._provider.getGasPrice(); // wei

        let estimatedTxFeeInEth = utils
          .parseEther(utils.formatUnits(_gasPrice, "ether"))
          .mul(config.GAS_USED_ESTIMATE);

        console.log({
          estimatedTxFeeInEth,
        });

        // Calculate net profit

        // WETHOUT - WETHIN - TXFEE
        let netProfit = utils
          .parseUnits(toTokenAmount, 0) // WETHOUT   -----------> USDC -> WETH
          .sub(utils.parseUnits(zrxOrder.makerAmount, 0)) // WETHIN
          .sub(estimatedTxFeeInEth);

        // Determine if profitable
        const profitable = netProfit.gt(0);

        // If profitable, then stop looking and trade!
        console.log({ profitable });

        if (profitable) {
          /// @dev set the bot to be on cooldown
          this.on_cooldown = true;

          const options = {
            leftPad: 0,
            columns: [
              { field: "profitable", name: chalk.cyan("Profitable?") },
              { field: "pair", name: chalk.cyan("Pair") },
              { field: "exchange", name: chalk.bgMagenta("Exchange Order") },
              { field: "fromToken", name: chalk.cyan("From Token") },
              { field: "toToken", name: chalk.cyan("To Token") },
              { field: "netprofit", name: chalk.bgMagenta("Net Profit") },
              { field: "timestamp", name: chalk.yellow("Time") },
            ],
            skinny: true,
          };
          // Log the arb
          const data = [
            {
              profitable: profitable,
              pair: `${baseToken.symbol}-${quoteToken.symbol}`,
              exchange: `0x, 1inxh`,
              fromToken: baseToken.symbol,
              toToken: quoteToken.symbol,
              netprofit: utils.formatUnits(
                netProfit,
                baseToken?.decimals || 18
              ),
              timestamp: new Date().toUTCString(),
            },
          ];
          const table = chalkTable(options, data);
          console.log(table);

          // Call arb trading bot contract
          try {
            console.log({
              fromTokenAmount: zrxOrder.makerAmount,
              baseToken,
              quoteToken,
              EST_USDC: fromTokenAmount,
              EST_WETH: toTokenAmount,
            });
            console.log({
              fromTokenAddress: quoteToken.address,
              toTokenAddress: baseToken.address,
              fromAddress: config.TRADING_BOT,
              destReceiver: config.TRADING_BOT,
              amount: fromTokenAmount, /// USDT  to WETH
              EST_WETH: toTokenAmount, // WETH we got
            });
            await tradingBotCall(
              baseToken.address,
              quoteToken.address,
              utils.parseUnits(zrxOrder.makerAmount, 0),
              zrxData,
              oneInchExchangeData
            );
            /// @dev update the bot to be not on cooldown

            this.on_cooldown = false;
          } catch (e) {
            console.log(e);

            /// @dev update the bot to be not on cooldown
            this.on_cooldown = false;
          }
        }
      }
    }
  };
}

export const tradingBotWrapper = new TradingBot();
