/** @format */

import { BigNumber, Contract, providers, utils, Wallet } from "ethers";
import config from "../../config";
import TradingBotABI from "./../constants/TradingBot.json";

const provider = new providers.JsonRpcProvider(config.JSON_RPC);

const signer = new Wallet(config.PRIVATE_KEY, provider);

const tradingBotIface = new utils.Interface(TradingBotABI);
const tradingBotContract = new Contract(
  config.TRADING_BOT,
  tradingBotIface,
  signer
);

export const tradingBotCall = async (
  fromToken: string,
  toToken: string,
  fromAmount: BigNumber,
  _zrxData: string,
  _oneInchCalllData: string
) => {
  try {
    // Perform Trade
    const receipt = await tradingBotContract.getFlashloan(
      fromToken, // address flashToken,
      fromAmount, // uint256 flashAmount,
      toToken, // address arbToken,
      _zrxData, // bytes calldata zrxData,
      _oneInchCalllData, //bytes calldata oneInchData
      {
        // gasLimit: config.GAS_LIMIT,
        // nonce,
        // gasPrice: (
        //   await getFastGas()
        // )
        //   .shiftedBy(9)
        //   .minus(nonce ? nonce : '1')
        //   .toString(),
      }
    );

    console.log("#####: receipt: ", receipt);

    /// @dev these events are important for debugging
    /// but you can remove them ofc
    tradingBotContract.events
      .StartBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: StartBalance:", event.returnValues);
      })
      .on("error", console.error);

    tradingBotContract.events
      .EndBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: EndBalance:", event.returnValues);
      })
      .on("error", console.error);

    tradingBotContract.events
      .ZRXBeforeDAIBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: ZRXBeforeDAIBalance:", event.returnValues);
      })
      .on("error", console.error);

    tradingBotContract.events
      .ZRXAfterDAIBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: ZRXAfterDAIBalance:", event.returnValues);
      })
      .on("error", console.error);

    tradingBotContract.events
      .ZRXBeforeWETHBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: ZRXBeforeWETHBalance:", event.returnValues);
      })
      .on("error", console.error);

    tradingBotContract.events
      .ZRXAfterWETHBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: ZRXAfterWETHBalance:", event.returnValues);
      })
      .on("error", console.error);

    tradingBotContract.events
      .OneInchBeforeWETHBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: OneInchBeforeWETHBalance:", event.returnValues);
      })
      .on("error", console.error);

    tradingBotContract.events
      .OneInchAfterWETHBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: OneInchAfterWETHBalance:", event.returnValues);
      })
      .on("error", console.error);

    tradingBotContract.events
      .OneInchBeforeDAIBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: OneInchBeforeDAIBalance:", event.returnValues);
      })
      .on("error", console.error);

    tradingBotContract.events
      .OneInchAfterDAIBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: OneInchAfterDAIBalance:", event.returnValues);
      })
      .on("error", console.error);

    tradingBotContract.events
      .FlashTokenBeforeBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: FlashTokenBeforeBalance:", event.returnValues);
      })
      .on("error", console.error);

    tradingBotContract.events
      .FlashTokenAfterBalance()
      .on("data", function (event: { returnValues: any }) {
        console.log("###: FlashTokenAfterBalance:", event.returnValues);
      })
      .on("error", console.error);
  } catch (err: any) {
    console.log("err:", err);

    throw new Error(err?.error?.message);
  }
};

export const zeroExCall = async () => {};
