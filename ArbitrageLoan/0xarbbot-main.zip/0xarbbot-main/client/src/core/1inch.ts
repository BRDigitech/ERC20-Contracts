import axios from "axios";
import config from "../../config";
import { Quote } from "./../types";
/**
 * A wrapper for interacting with 1inch exchange API
 *
 * @docs https://docs.1inch.io/docs/aggregation-protocol/guide/quick-start/
 */
class OneInchWrapper {
  private baseUrl: string;

  constructor() {
    this.baseUrl = `https://api.1inch.io/v4.0/${config.CHAIN_ID}`;
  }
  /**
   * Gets the best exchange rate for a given pair
   * @param params.fromTokenAddress - from token
   * @param params.toTokenAddress - to token
   * @param params.amount - from token amount
   * @param params.side - trade direction i.e buy or sell
   * @returns best quote found
   */
  getQuote = async (params: {
    fromTokenAddress: string;
    toTokenAddress: string;
    amount: number | string;
    side?: string;
  }): Promise<Quote> => {
    const { fromTokenAddress, toTokenAddress, amount, side } = params;
    try {
      const { data } = await axios({
        method: "GET",
        url: `${this.baseUrl}/${config.CHAIN_ID}/quote`,
        params: {
          fromTokenAddress,
          toTokenAddress,
          amount,
        },
      });
      return {
        srcToken: data.fromToken,
        srcAmount: data.fromTokenAmount,
        toToken: data.toToken,
        toAmount: data.toTokenAmount,
        protocols: data.protocols,
      };
    } catch (error: any) {
      error = error?.response?.data;

      throw new Error(
        error?.description || `${error?.statusCode} ${error?.error}`
      );
    }
  };
  /**
   * Builds a tx based on the given params
   * @param params.fromTokenAddress - from Token
   * @param params.toTokenAddress - to Token
   * @param params.amount - from Token amount
   * @param params.slippage - slippage tolerance
   * @param params.gasLimit - gasLimit
   * @returns tx data that can be send to the network
   */
  buildTx = async (params: {
    fromTokenAddress: string;
    toTokenAddress: string;
    amount: number | string;
    slippage?: number;
    gasLimit?: string;
    fromAddress?: string;
    destReceiver?: string;
  }) => {
    const {
      fromTokenAddress,
      toTokenAddress,
      amount,
      slippage,
      destReceiver,
      fromAddress,
    } = params;
    try {
      let defaultSlippage = 0.5;

      const { data } = await axios({
        method: "GET",
        baseURL: this.baseUrl,
        url: `/swap`,
        params: {
          fromTokenAddress,
          toTokenAddress,
          amount,
          fromAddress,
          destReceiver,
          slippage: slippage || defaultSlippage,
          disableEstimate: true,
        },
      });

      // const { data } = await axios.get(
      //   `https://api.1inch.exchange/v4.0/1/swap?fromTokenAddress=${fromTokenAddress}&toTokenAddress=${toTokenAddress}&amount=${amount}&fromAddress=${fromAddress}&slippage=${defaultSlippage}&disableEstimate=true`
      // );
      delete data.tx.gasPrice; //ethersjs will find the gasPrice needed
      delete data.tx.gas;

      return {
        oneInchExchangeData: data.tx?.data,
        toTokenAmount: data.toTokenAmount,
      };
    } catch (error: any) {
      throw new Error(JSON.stringify(error));
    }
  };

  /**
   * Builds both buy and sell tx data
   * @param buy_quote Buy `Quote`
   * @param sell_quote Sell `Quote`
   * @returns both buy and sell tx data that can submitted via a provider to the chain
   */
  buildBuynSellTxData = async (buy_quote: Quote, sell_quote: Quote) => {
    let _oneInchCallBuyData = await this.buildTx({
      fromTokenAddress: buy_quote.srcToken.address,
      toTokenAddress: buy_quote.toToken.address,
      amount: buy_quote.srcAmount,
      fromAddress: config.TRADING_BOT,
    });
    let _oneInchCallSellData = await this.buildTx({
      fromTokenAddress: sell_quote.srcToken.address,
      toTokenAddress: sell_quote.toToken.address,
      amount: sell_quote.srcAmount,
      fromAddress: config.TRADING_BOT,
    });
    console.log({
      sell_quote: sell_quote.srcAmount,
    });

    return {
      _oneInchCallBuyData,
      _oneInchCallSellData,
    };
  };

  /**
   * Gets supported protocols by 1inch price aggregator
   * @returns Supported protocols by 1inch price aggregator
   */
  getProtocols = async (): Promise<string[]> => {
    try {
      const { data }: any = await axios({
        method: "GET",
        url: `${this.baseUrl}/liquidity-sources`,
      });
      return data.protocols;
    } catch (error) {
      console.log(error);

      throw new Error(JSON.stringify(error));
    }
  };
}

export const oneInchWrapper = new OneInchWrapper();
