import axios from "axios";
import { Bid } from "../types";

/**
 * A wrapper for interactin with 0x.org protocol orderbook
 *
 *  @docs  https://docs.0x.org/0x-api-orderbook/introduction
 */
class ZeroX {
  private baseUrl: string;

  constructor() {
    this.baseUrl = `https://api.0x.org`;
  }

  /**
   * Retrieves the orderbook for a given asset pair.
   * @param quoteToken The address of makerToken or takerToken designated as the quote currency in the currency pair calculation of price.
   * @param baseToken The address of makerToken or takerToken designated as the base currency in the currency pair calculation of price.
   *
   *  @dev Bids will be sorted in descending order by price
   *
   * @returns an array of Bid orders
   */
  getOrderBook = async (
    baseToken: string,
    quoteToken: string
  ): Promise<Bid[]> => {
    try {
      const { data } = await axios({
        method: "GET",
        baseURL: this.baseUrl,
        url: `/orderbook/v1`,
        params: {
          baseToken,
          quoteToken,
        },
      });

      return data.bids.records;
    } catch (error: any) {
      console.log({ error });
      throw new Error(error);
    }
  };
  fetchOrder = async (orderHash: string) => {
    let order = null;
    try {
      const { data } = await axios({
        method: "GET",
        baseURL: this.baseUrl,
        url: `/orderbook/v1/order/${orderHash}`,
      });
      order = data?.data;
    } catch (error) {
      console.error(`Error while fetching order ${orderHash}`);
    }

    return order;
  };
  fetchQuote = async (params: {
    sellToken: string;
    buyToken: string;
    sellAmount: string;
  }) => {
    let quote = null;
    try {
      const { data } = await axios({
        method: "GET",
        baseURL: this.baseUrl,
        url: `/swap/v1/quote`,
        params,
      });
      return { data: data?.data, buyAmount: data?.buyAmount };
    } catch (error) {
      throw new Error(
        `Error while fetching quote for ${params.sellToken}-${params.buyToken}, ${error}`
      );
    }
  };
}

export const zrxWrapper = new ZeroX();
