/** @format */
import { Token } from "../types";
export const TOKENS: Record<string, Token> = {
  DAI: {
    address: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    decimals: 18,
    symbol: "DAI",
    name: "DAI",
  },
  USDC: {
    address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    decimals: 6,
    symbol: "USDC",
    name: "USDC",
  },
  WETH: {
    address: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2",
    decimals: 18,
    symbol: "WETH",
    name: "Wrapped ETH",
  },
  //New
  USDT: {
    address: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
    decimals: 6,
    symbol: "USDT",
    name: "Tether USD",
  },
  BTC: {
    address: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
    decimals: 8,
    symbol: "WBTC",
    name: "Wrapped BTC",
  },
  UST: {
    address: "0xa47c8bf37f92aBed4A126BDA807A7b7498661acD",
    decimals: 18,
    symbol: "UST",
    name: "Wrapped UST Token",
  },
  SAND: {
    address: "0x3845badAde8e6dFF049820680d1F14bD3903a5d0",
    decimals: 18,
    symbol: "SAND",
    name: "SAND",
  },
  MANA: {
    address: "0x0F5D2fB29fb7d3CFeE444a200298f468908cC942",
    decimals: 18,
    symbol: "MANA",
    name: "Decentraland MANA",
  },
  LINK: {
    address: "0x514910771AF9Ca656af840dff83E8264EcF986CA",
    decimals: 18,
    symbol: "LINK",
    name: "ChainLink Token",
  },
  FRAX: {
    address: "0x3432B6A60D23Ca0dFCa7761B7ab56459D9C964D0",
    decimals: 18,
    symbol: "FXS",
    name: "Frax Share",
  },
  SUSHI: {
    address: "0x6B3595068778DD592e39A122f4f5a5cF09C90fE2",
    decimals: 18,
    symbol: "SUSHI",
    name: "SushiToken",
  },
  UNI: {
    address: "0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984",
    decimals: 18,
    symbol: "UNI",
    name: "Uniswap",
  },
  FTM: {
    address: "0x4E15361FD6b4BB609Fa63C81A2be19d873717870",
    decimals: 18,
    symbol: "FTM",
    name: "Fantom Token",
  },
  LUNA: {
    address: "0xd2877702675e6cEb975b4A1dFf9fb7BAF4C91ea9",
    decimals: 18,
    symbol: "LUNA",
    name: "Wrapped LUNA Token",
  },
  SHIB: {
    address: "0x228619CCa194Fbe3Ebeb2f835eC1eA5080DaFbb2",
    decimals: 8,
    symbol: "crXSUSHI",
    name: "Cream SushiBar",
  },
  AXS: {
    address: "0xBB0E17EF65F82Ab018d8EDd776e8DD940327B28b",
    decimals: 18,
    symbol: "AXS",
    name: "Axie Infinity Shard",
  },
  APE: {
    address: "0xc770EEfAd204B5180dF6a14Ee197D99d808ee52d",
    decimals: 18,
    symbol: "FOX",
    name: "FOX",
  },
  RUNE: {
    address: "0x3155BA85D5F96b2d030a4966AF206230e46849cb",
    decimals: 18,
    symbol: "RUNE",
    name: "THORChain ETH.RUNE",
  },
  AAVE: {
    address: "0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9",
    decimals: 18,
    symbol: "AAVE",
    name: "AAVE",
  },
  MKR: {
    address: "0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2",
    decimals: 18,
    symbol: "MKR",
    name: "MKR",
  },
  ENJ: {
    address: "0xF629cBd94d3791C9250152BD8dfBDF380E2a3B9c",
    decimals: 18,
    symbol: "ENJ",
    name: "Enjin Coin",
  },
  TUSD: {
    address: "0x0000000000085d4780B73119b644AE5ecd22b376",
    decimals: 18,
    symbol: "TUSD",
    name: "TrueUSD",
  },
  COMP: {
    address: "0xc00e94Cb662C3520282E6f5717214004A7f26888",
    decimals: 18,
    symbol: "COMP",
    name: "Compound",
  },
  YFI: {
    address: "0x0bc529c00c6401aef6d220be8c6ea1667f6ad93e",
    decimals: 18,
    symbol: "YFI",
    name: "yearn.finance",
  },
};
export const PAIRS = {
  //WETH
  WETH_DAI: {
    quote: TOKENS.DAI,
    base: TOKENS.WETH,
  },
  WETH_USDC: {
    quote: TOKENS.USDC,
    base: TOKENS.WETH,
  },
  WETH_USDT: {
    quote: TOKENS.USDT,
    base: TOKENS.WETH,
  },
  WETH_BTC: {
    quote: TOKENS.BTC,
    base: TOKENS.WETH,
  },
  WETH_UST: {
    quote: TOKENS.UST,
    base: TOKENS.WETH,
  },
  WETH_SAND: {
    quote: TOKENS.SAND,
    base: TOKENS.WETH,
  },
  WETH_MANA: {
    quote: TOKENS.MANA,
    base: TOKENS.WETH,
  },
  WETH_LINK: {
    quote: TOKENS.LINK,
    base: TOKENS.WETH,
  },
  WETH_FRAX: {
    quote: TOKENS.FRAX,
    base: TOKENS.WETH,
  },
  WETH_SUSHI: {
    quote: TOKENS.SUSHI,
    base: TOKENS.WETH,
  },
  WETH_UNI: {
    quote: TOKENS.UNI,
    base: TOKENS.WETH,
  },
  WETH_FTM: {
    quote: TOKENS.FTM,
    base: TOKENS.WETH,
  },
  WETH_LUNA: {
    quote: TOKENS.LUNA,
    base: TOKENS.WETH,
  },
  WETH_SHIB: {
    quote: TOKENS.SHIB,
    base: TOKENS.WETH,
  },
  WETH_AXS: {
    quote: TOKENS.AXS,
    base: TOKENS.WETH,
  },
  WETH_APE: {
    quote: TOKENS.APE,
    base: TOKENS.WETH,
  },
  WETH_RUNE: {
    quote: TOKENS.RUNE, // TODO check
    base: TOKENS.WETH,
  },
  WETH_AAVE: {
    quote: TOKENS.AAVE,
    base: TOKENS.WETH,
  },
  WETH_MKR: {
    quote: TOKENS.MKR,
    base: TOKENS.WETH,
  },
  WETH_ENJ: {
    quote: TOKENS.ENJ,
    base: TOKENS.WETH,
  },
  WETH_TUSD: {
    quote: TOKENS.TUSD,
    base: TOKENS.WETH,
  },
  WETH_COMP: {
    quote: TOKENS.COMP,
    base: TOKENS.WETH,
  },
  WETH_YFI: {
    quote: TOKENS.YFI,
    base: TOKENS.WETH,
  },
  //DAI
  DAI_WETH: {
    quote: TOKENS.WETH,
    base: TOKENS.DAI,
  },
  DAI_USDC: {
    quote: TOKENS.USDC,
    base: TOKENS.DAI,
  },
  DAI_USDT: {
    quote: TOKENS.USDT,
    base: TOKENS.DAI,
  },
  DAI_BTC: {
    quote: TOKENS.BTC,
    base: TOKENS.DAI,
  },
  DAI_UST: {
    quote: TOKENS.UST,
    base: TOKENS.DAI,
  },
  DAI_SAND: {
    quote: TOKENS.SAND,
    base: TOKENS.DAI,
  },
  DAI_MANA: {
    quote: TOKENS.MANA,
    base: TOKENS.DAI,
  },
  DAI_LINK: {
    quote: TOKENS.LINK,
    base: TOKENS.DAI,
  },
  DAI_FRAX: {
    quote: TOKENS.FRAX,
    base: TOKENS.DAI,
  },
  DAI_SUSHI: {
    quote: TOKENS.SUSHI,
    base: TOKENS.DAI,
  },
  DAI_UNI: {
    quote: TOKENS.UNI,
    base: TOKENS.DAI,
  },
  DAI_FTM: {
    quote: TOKENS.FTM,
    base: TOKENS.DAI,
  },
  DAI_LUNA: {
    quote: TOKENS.LUNA,
    base: TOKENS.DAI,
  },
  DAI_SHIB: {
    quote: TOKENS.SHIB,
    base: TOKENS.DAI,
  },
  DAI_AXS: {
    quote: TOKENS.AXS,
    base: TOKENS.DAI,
  },
  DAI_APE: {
    quote: TOKENS.APE,
    base: TOKENS.DAI,
  },
  DAI_RUNE: {
    quote: TOKENS.RUNE,
    base: TOKENS.DAI,
  },
  DAI_AAVE: {
    quote: TOKENS.AAVE,
    base: TOKENS.DAI,
  },
  DAI_MKR: {
    quote: TOKENS.MKR,
    base: TOKENS.DAI,
  },
  DAI_ENJ: {
    quote: TOKENS.ENJ,
    base: TOKENS.DAI,
  },
  DAI_TUSD: {
    quote: TOKENS.TUSD,
    base: TOKENS.DAI,
  },
  DAI_COMP: {
    quote: TOKENS.COMP,
    base: TOKENS.DAI,
  },
  DAI_YFI: {
    quote: TOKENS.YFI,
    base: TOKENS.DAI,
  },
  //end DAI
  //USDC
  USDC_WETH: {
    quote: TOKENS.WETH,
    base: TOKENS.USDC,
  },
  USDC_DAI: {
    quote: TOKENS.DAI,
    base: TOKENS.USDC,
  },
  USDC_USDT: {
    quote: TOKENS.USDT,
    base: TOKENS.USDC,
  },
  USDC_BTC: {
    quote: TOKENS.BTC,
    base: TOKENS.USDC,
  },
  USDC_UST: {
    quote: TOKENS.UST,
    base: TOKENS.USDC,
  },
  USDC_SAND: {
    quote: TOKENS.SAND,
    base: TOKENS.USDC,
  },
  USDC_MANA: {
    quote: TOKENS.MANA,
    base: TOKENS.USDC,
  },
  USDC_LINK: {
    quote: TOKENS.LINK,
    base: TOKENS.USDC,
  },
  USDC_FRAX: {
    quote: TOKENS.FRAX,
    base: TOKENS.USDC,
  },
  USDC_SUSHI: {
    quote: TOKENS.SUSHI,
    base: TOKENS.USDC,
  },
  USDC_UNI: {
    quote: TOKENS.UNI,
    base: TOKENS.USDC,
  },
  USDC_FTM: {
    quote: TOKENS.FTM,
    base: TOKENS.USDC,
  },
  USDC_LUNA: {
    quote: TOKENS.LUNA,
    base: TOKENS.USDC,
  },
  USDC_SHIB: {
    quote: TOKENS.SHIB,
    base: TOKENS.USDC,
  },
  USDC_AXS: {
    quote: TOKENS.AXS,
    base: TOKENS.USDC,
  },
  USDC_APE: {
    quote: TOKENS.APE,
    base: TOKENS.USDC,
  },
  USDC_RUNE: {
    quote: TOKENS.RUNE,
    base: TOKENS.USDC,
  },
  USDC_AAVE: {
    quote: TOKENS.AAVE,
    base: TOKENS.USDC,
  },
  USDC_MKR: {
    quote: TOKENS.MKR,
    base: TOKENS.USDC,
  },
  USDC_ENJ: {
    quote: TOKENS.ENJ,
    base: TOKENS.USDC,
  },
  USDC_TUSD: {
    quote: TOKENS.TUSD,
    base: TOKENS.USDC,
  },
  USDC_COMP: {
    quote: TOKENS.COMP,
    base: TOKENS.USDC,
  },
  USDC_YFI: {
    quote: TOKENS.YFI,
    base: TOKENS.USDC,
  },
  //end USDC
};
console.log({ PAIRS });
