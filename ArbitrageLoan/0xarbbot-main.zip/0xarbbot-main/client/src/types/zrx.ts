export interface Bid {
  order: Order;
  metaData: MetaData;
}

export interface MetaData {
  orderHash: string;
  remainingFillableTakerAmount: string;
  createdAt?: Date;
}

export interface Order {
  signature?: Signature;
  sender?: string;
  maker?: string;
  taker?: string;
  takerTokenFeeAmount?: string;
  makerAmount: string;
  takerAmount?: string;
  makerToken?: string;
  takerToken?: string;
  salt: string;
  verifyingContract?: string;
  feeRecipient?: string;
  expiry?: string;
  chainId?: number;
  pool?: string;
}

export interface Signature {
  signatureType?: number;
  r?: string;
  s?: string;
  v?: number;
}
