import "dotenv/config";

if (
  !process.env.PRIVATE_KEY &&
  !process.env.PUBLIC_KEY &&
  !process.env.JSON_RPC
) {
  throw new Error(
    "PRIVATE_KEY, PUBLIC_KEY, JSON_RPC Must be in your .env file"
  );
}

const config = {
  CHAIN_ID: 1,

  /**
   * WALLET
   */
  PRIVATE_KEY: process.env.PRIVATE_KEY!,
  PUBLIC_KEY: process.env.PUBLIC_KEY!,

  /**
   * PROVIDER
   */
  JSON_RPC: process.env.JSON_RPC!,

  /**
   * EXPLORER
   */
  EXPLORER: "https://etherscan.io",

  //
  ETH_IN_AMOUNT: 2,

  // GAS_USED_ESTIMATE
  GAS_USED_ESTIMATE: 600_000,
  /**
   * TELEGRAM
   */
  WHITELISTED_USERS: ["251669027"], // users that will receive tg notifications
  BOT_TOKEN: process.env.BOT_TOKEN!,

  /**
   * Trading bot
   */
  TRADING_BOT: "0xc582Bc0317dbb0908203541971a358c44b1F3766",
  GAS_LIMIT: 4e5,
  WETH_ADDRESS: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",

  /**
   * Check markets every n seconds
   */
  POLLING_INTERVAL: 45,
};
export default config;
