# DyDxFlashLoan









## Methods

### DAI

```solidity
function DAI() external view returns (address)
```






#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

### SAI

```solidity
function SAI() external view returns (address)
```






#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

### USDC

```solidity
function USDC() external view returns (address)
```






#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

### WETH

```solidity
function WETH() external view returns (address)
```



*Assets availabe for flashloan at DyDx*


#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

### currencies

```solidity
function currencies(address) external view returns (uint256)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | uint256 | undefined |

### tokenToMarketId

```solidity
function tokenToMarketId(address token) external view returns (uint256)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| token | address | undefined |

#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | uint256 | undefined |



## Events

### EndBalance

```solidity
event EndBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### FlashTokenAfterBalance

```solidity
event FlashTokenAfterBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### FlashTokenBeforeBalance

```solidity
event FlashTokenBeforeBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchAfterDAIBalance

```solidity
event OneInchAfterDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchAfterWETHBalance

```solidity
event OneInchAfterWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchBeforeDAIBalance

```solidity
event OneInchBeforeDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchBeforeWETHBalance

```solidity
event OneInchBeforeWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### StartBalance

```solidity
event StartBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXAfterDAIBalance

```solidity
event ZRXAfterDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXAfterWETHBalance

```solidity
event ZRXAfterWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXBeforeDAIBalance

```solidity
event ZRXBeforeDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXBeforeWETHBalance

```solidity
event ZRXBeforeWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |



