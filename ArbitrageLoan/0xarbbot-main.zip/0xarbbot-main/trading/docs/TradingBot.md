# TradingBot









## Methods

### DAI

```solidity
function DAI() external view returns (address)
```






#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

### SAI

```solidity
function SAI() external view returns (address)
```






#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

### USDC

```solidity
function USDC() external view returns (address)
```






#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

### WETH

```solidity
function WETH() external view returns (address)
```






#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

### ZRX_ERC20_PROXY_ADDRESS

```solidity
function ZRX_ERC20_PROXY_ADDRESS() external view returns (address)
```






#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

### ZRX_EXCHANGE_ADDRESS

```solidity
function ZRX_EXCHANGE_ADDRESS() external view returns (address)
```






#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

### approveWeth

```solidity
function approveWeth(uint256 _amount) external nonpayable
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| _amount | uint256 | undefined |

### arb

```solidity
function arb(address _fromToken, address _toToken, uint256 _fromAmount, bytes _0xData, bytes _oneInchData) external payable
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| _fromToken | address | undefined |
| _toToken | address | undefined |
| _fromAmount | uint256 | undefined |
| _0xData | bytes | undefined |
| _oneInchData | bytes | undefined |

### callFunction

```solidity
function callFunction(address, ITrading.Info, bytes data) external nonpayable
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |
| _1 | ITrading.Info | undefined |
| data | bytes | undefined |

### currencies

```solidity
function currencies(address) external view returns (uint256)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | uint256 | undefined |

### getFlashloan

```solidity
function getFlashloan(address flashToken, uint256 flashAmount, address arbToken, bytes zrxData, bytes oneInchData) external payable
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| flashToken | address | undefined |
| flashAmount | uint256 | undefined |
| arbToken | address | undefined |
| zrxData | bytes | undefined |
| oneInchData | bytes | undefined |

### getRouter

```solidity
function getRouter() external view returns (address)
```



*Fetches the current oneinch router*


#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | address | undefined |

### getWeth

```solidity
function getWeth() external payable
```






### loan

```solidity
function loan() external view returns (uint256)
```






#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | uint256 | undefined |

### oneInchSwap

```solidity
function oneInchSwap(address _from, address _to, uint256 _amount, bytes _oneInchCallData) external payable
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| _from | address | undefined |
| _to | address | undefined |
| _amount | uint256 | undefined |
| _oneInchCallData | bytes | undefined |

### setRouter

```solidity
function setRouter(address _newRouter) external nonpayable
```



*Lets a contract admin set the URI for the contract-level metadata.*

#### Parameters

| Name | Type | Description |
|---|---|---|
| _newRouter | address | undefined |

### setZRXERC20ProxyAddress

```solidity
function setZRXERC20ProxyAddress(address _newZRXERC20ProxyAddress) external nonpayable
```



*Lets a contract admin set the  zrx erc20 proxy address*

#### Parameters

| Name | Type | Description |
|---|---|---|
| _newZRXERC20ProxyAddress | address | undefined |

### setZRXExchangeAddress

```solidity
function setZRXExchangeAddress(address _newZRXExchangeAddress) external nonpayable
```



*Lets a contract admin set the  zrx exchange address*

#### Parameters

| Name | Type | Description |
|---|---|---|
| _newZRXExchangeAddress | address | undefined |

### tokenToMarketId

```solidity
function tokenToMarketId(address token) external view returns (uint256)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| token | address | undefined |

#### Returns

| Name | Type | Description |
|---|---|---|
| _0 | uint256 | undefined |

### trade

```solidity
function trade(address _fromToken, address _toToken, uint256 _fromAmount, bytes _0xData, bytes _1inchData) external payable
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| _fromToken | address | undefined |
| _toToken | address | undefined |
| _fromAmount | uint256 | undefined |
| _0xData | bytes | undefined |
| _1inchData | bytes | undefined |

### withdrawEther

```solidity
function withdrawEther() external nonpayable
```



*Keep this function in case the contract keeps leftover ether!*


### withdrawToken

```solidity
function withdrawToken(address _tokenAddress) external nonpayable
```



*Keep this function in case the contract receives tokens!*

#### Parameters

| Name | Type | Description |
|---|---|---|
| _tokenAddress | address | undefined |

### zrxSwap

```solidity
function zrxSwap(address _from, uint256 _amount, bytes _calldataHexString) external payable
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| _from | address | undefined |
| _amount | uint256 | undefined |
| _calldataHexString | bytes | undefined |



## Events

### EndBalance

```solidity
event EndBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### FlashTokenAfterBalance

```solidity
event FlashTokenAfterBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### FlashTokenBeforeBalance

```solidity
event FlashTokenBeforeBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchAfterDAIBalance

```solidity
event OneInchAfterDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchAfterWETHBalance

```solidity
event OneInchAfterWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchBeforeDAIBalance

```solidity
event OneInchBeforeDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchBeforeWETHBalance

```solidity
event OneInchBeforeWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### StartBalance

```solidity
event StartBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXAfterDAIBalance

```solidity
event ZRXAfterDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXAfterWETHBalance

```solidity
event ZRXAfterWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXBeforeDAIBalance

```solidity
event ZRXBeforeDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXBeforeWETHBalance

```solidity
event ZRXBeforeWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |



