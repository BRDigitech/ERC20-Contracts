# ITrading










## Events

### EndBalance

```solidity
event EndBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### FlashTokenAfterBalance

```solidity
event FlashTokenAfterBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### FlashTokenBeforeBalance

```solidity
event FlashTokenBeforeBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchAfterDAIBalance

```solidity
event OneInchAfterDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchAfterWETHBalance

```solidity
event OneInchAfterWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchBeforeDAIBalance

```solidity
event OneInchBeforeDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### OneInchBeforeWETHBalance

```solidity
event OneInchBeforeWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### StartBalance

```solidity
event StartBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXAfterDAIBalance

```solidity
event ZRXAfterDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXAfterWETHBalance

```solidity
event ZRXAfterWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXBeforeDAIBalance

```solidity
event ZRXBeforeDAIBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |

### ZRXBeforeWETHBalance

```solidity
event ZRXBeforeWETHBalance(uint256 balance)
```





#### Parameters

| Name | Type | Description |
|---|---|---|
| balance  | uint256 | undefined |



