# Trading Bot

Trading bot that utilizes custom Solidity contracts, in conjunction with decentralized exchange contracts, to capture profit from token arbitrage opportunities on any EVM compatible blockchain.

To potential employers reviewing my work, please reach out if you wish to see a private fork of this repo (currently in progress) with more complexity and DEX integration, along with more in-depth tests.

## Background

Check out https://ethereum.org/en/developers/docs/mev/ for context on this project.

There are positives to MEV. DEXs require arbitrage "searchers" to ensure price correctness and stability for their protocols. However, I'm not claiming to be saving the world here :) Just a fun project to sharpen my skills in DEFI related development.

## Design

## Technologies

Javascript/Node.js, Solidity, Hardhat, Ethers.js, Waffle.

## Bot Strategy Overview

Before getting into the code, we will explain and test the strategy chosen for the bot using just the 0x API and the 1inch dex aggregator contract, the only tool needed for now is a browser with the Metamask extension installed.

Using orderbooks, developers can fill limit orders from a decentralized exchange and then see if the tokens aquired in the first step could be sold for more to ANY other liquidity pool. This is the strategy that will be used for the arbitrage bot in this article. In particular, the bot will query the 0x API looking for WETH/DAI pair limit orders, the bot will then query the [1inch exchange](https://1inch.exchange/#/) DEX aggregator in order to determine whether one or more of the open orders from 0x, i.e. ETH, could be sold for a higher price on any other liquidity pool.

The table below shows the currency pairs that the trading bot will look for and the exchanges that it's going to use.

|             | 0x   | 1inch |
| ----------- | ---- | ----- |
| Maker Asset | WETH | DAI   |
| Taker Asset | DAI  | WETH  |

The bot will use the 'taker' assets, i.e. it will sell DAI on 0x and sell WETH on 1inch.
Let's break down the steps from the above table:

1. Get a flashloan in DAI from DyDx exchange
2. Buy WETH from 0x usning DAI borrowed with the flashloan
3. Use 1inch to find the best exchange to sell the WETH aquired in step 2
4. Pay back the flashloan in DAI and keep the difference if any (profit)

In case the readers aren't familiar, WETH is the ERC20 tradable version of ETH.
WETH makes it easier to trade ETH from the point of view of smart contracts, it also means that users can revoke access to their WETH after sending it to an exchange, while that's not the case for ETH.

### 0x Protocol

0x is a protocol for doing wallet to wallet trading by using an off-chain API that stores the orders for the orderbook and a trading protocol enforced by smart contracts.

Radar Relay is just an example of a DEX that is powered by the 0x protocol, i.e. it is possible to use the [0x API](https://0x.org/docs/api) in order to get limit orders for a currency pair from every exchange that uses the 0x protocol.

#### Fetching Orderbook Data

[This url](https://api.0x.org/sra/v3/orders?page=1&perPage=1000&makerAssetProxyId=0xf47261b0&takerAssetProxyId=0xf47261b0&makerAssetAddress=0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2&takerAssetAddress=0x6b175474e89094c44da98b954eedeac495271d0f) will effectively perform a get request to the 0x API in order to retrieve all limit orders for the WETH/DAI pair. The url takes two main parameters: the maker token's contract address (WETH) and the taker token's contract address (DAI), i.e. this is the API call to use if we wanted to buy WETH using DAI. See the [0x docs](https://0x.org/docs/api#request-9) regarding orderbook requests for more information.

Let's analyze the response from the 0x API, the following object is just one order out of the many returned in the previous call.

```
"order": {
        "signature": "0x1b5ee7412dcf084cc19131e7d78ebfafa2cae8fc4b1e1f2b49dde218334bab51f06b4c1f91da6e3f3277445c5235628886bff304951fac0c9f99f613f9a42bded302",
        "senderAddress": "0x0000000000000000000000000000000000000000",
        "makerAddress": "0x0ee1f33a2eb0da738fdf035c48d62d75e996a3bd",
        "takerAddress": "0x0000000000000000000000000000000000000000",
        "makerFee": "0",
        "takerFee": "0",
        "makerAssetAmount": "20000000000000000",
        "takerAssetAmount": "7808584000000000000",
        "makerAssetData": "0xf47261b0000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc2",
        "takerAssetData": "0xf47261b00000000000000000000000006b175474e89094c44da98b954eedeac495271d0f",
        "salt": "95222041148024943540833237129371349480418435215051967676171665233326083547721",
        "exchangeAddress": "0x61935cbdd02287b511119ddb11aeb42f1593b7ef",
        "feeRecipientAddress": "0x86003b044f70dac0abc80ac8957305b6370893ed",
        "expirationTimeSeconds": "1604395325",
        "makerFeeAssetData": "0x",
        "chainId": 1,
        "takerFeeAssetData": "0x"
      },
```

The important bits from the order above are maker and taker amounts:

```
"makerAssetAmount": "20000000000000000",
"takerAssetAmount": "7808584000000000000",
```

The maker amount is the amount of WETH for sale on that particular order followed by 18 decimal places, while the taker amount is in DAI, also followed by 18 decimal places.

In order to find out the DAI price of 1 ETH, we divide taker amout by maker amount, using the command line to avoid counting zeroes:

```
echo 7808584000000000000/20000000000000000 | bc
```

The result is 390 (DAI for 1 WETH). Next, we check whether we could sell the WETH on a liquidity pool for more than 390 USD.

### 1inch DEX Aggregator

> 1inch offers the best rates by discovering the most efficient swapping routes across all leading DEXes.

It may be useful for the reader to know that another popular DEX aggregator exists called [DEX.AG](https://dex.ag/). 1inch is essentially a smart contract that can be queried in various ways, the easiest way to do so is via the UI as shown in the picture above, however the same exact thing can be achieved by queryng the smart contract directly [on Etherscan](https://etherscan.io/address/0xc586bef4a0992c495cf22e1aeee4e446cecdee0e#readContract).

The above function was filled in with the WETH and DAI contract addresses and the taker asset amount, i.e. 0.2 WETH as shown in the example order from 0x. The idea is that if this amount is greater than the one returned by 0x, then there is a profitable arbitrage opportunity. We can use the command line again to determine profitability.

```
echo 8000442481503500755/20000000000000000 | bc
```

which results in 400. Therefore, we could buy 1 WETH for 390 DAI on 0x and sell 1 WETH for 400 on 1inch, making a 10 DAI profit (minus fees). However, a few minutes have gone by while writing this article between the 0x API query and the 1inch contract query which means that this opportunity may not actually exist in practice, because we would need both limit orders to exist at the same time for the arbitrage to work.
