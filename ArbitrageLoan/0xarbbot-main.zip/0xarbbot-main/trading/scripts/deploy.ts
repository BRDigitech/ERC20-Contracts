import hre, { ethers } from "hardhat";
import config from "../config";

// Types
import { Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";

// Utils
async function main(): Promise<void> {
  // Get deployer
  const [deployer]: SignerWithAddress[] = await ethers.getSigners();
  const networkName: string = hre.network.name;

  console.log(`Deploying contracts with account: ${await deployer.getAddress()} to ${networkName}.`);

  // Deploy TradingBot
  const TradingBot_Factory = await ethers.getContractFactory("TradingBot");
  const tradingBot = await TradingBot_Factory.connect(deployer).deploy(config.ONEINCH_ROUTER, {
    gasLimit: 1000000,
  });
  await tradingBot.deployed();
  console.log(`Deploying Trading Bot: ${tradingBot.address} at tx hash: ${tradingBot.deployTransaction.hash}`);
}

main()
  .then(() => process.exit(0))
  .catch(error => {
    console.error(error);
    process.exit(1);
  });
