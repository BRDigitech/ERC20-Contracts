# 0xarbbot
A bot that does arbitrage on 0x and 1inch protocols
